# Keystone AI Protocols — Tier 03 Sovereign Workstation Suite ($800.00 USD)
## Complete Runnable Tauri v2 Desktop Command Center & Standalone Windows .EXE Pipeline
**Author**: Wayne Stevenson (BC Housing Licensed Builder #52603 • Systems Architect)
**Portal**: https://keystonerecomposition.com/ai-protocols/

Welcome to **Tier 03 ($800.00 USD Flagship)**! Tier 03 provides everything you need to package your AI Brain, Multi-Agent Swarm, and workflow buttons into a **single, standalone Windows `.EXE` desktop application** built with **Tauri v2** and **Rust**.

---

### What Is Inside This Flagship Package:
1. **`tauri_command_center_starter/`** (Complete, clean-room, runnable Tauri v2 desktop application):
   - `package.json` — Tauri v2 CLI dependencies.
   - `src/index.html` — Dark-luxury multi-tab dashboard (#04070d Obsidian, #d4af37 Gold, #38bdf8 Cyan).
   - `src/styles.css` — 18px rounded glass cards & 9999px pill buttons.
   - `src/app.js` — Client-side JavaScript calling Rust IPC commands with browser fallback.
   - `src-tauri/Cargo.toml` — High-performance Rust dependencies.
   - `src-tauri/build.rs` — Tauri build script.
   - `src-tauri/tauri.conf.json` — Tauri v2 application configuration.
   - `src-tauri/capabilities/default.json` — Tauri v2 desktop permissions.
   - `src-tauri/src/main.rs` — Real typed `#[tauri::command]` handlers for system status, folder health check, and workflow tasks.

2. **`BUILD_YOUR_EXE_QUICKSTART.md`** — Step-by-step instructions to compile your single standalone `.exe` using `npm run tauri build`.

3. **`14_DAY_GUIDED_SETUP_SUPPORT_GUIDE.md`** — Guided setup support intake worksheet & architecture Q&A guide (up to 8 questions answered directly by email).

4. **`09_ANTIGRAVITY_APP_BUILDER_PROMPTS/`**:
   - `01_SCAFFOLD_TAURI_V2_PROMPT.md`
   - `02_ADD_COMMAND_CENTER_TAB_PROMPT.md`
   - `03_WIRE_RUST_IPC_COMMAND_PROMPT.md`
   - `04_PACKAGE_WINDOWS_EXE_PROMPT.md`

5. **`PDF_Guides/`**: `KR_T3_10` through `KR_T3_12` + `KR_T3_00_ALL_3_TIER03_GUIDES_COMBINED.pdf`.

6. **`Architecture_Diagrams/`**: `Diagram_04` & `Diagram_05` (.svg and .png).
