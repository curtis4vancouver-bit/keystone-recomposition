# Prompt 01: Scaffold Tauri v2 App

```text
You are my Lead Systems Architect. Help me scaffold a clean Tauri v2 desktop application using vanilla HTML5, CSS (#04070d, #d4af37, #38bdf8), and typed Rust commands.
```
