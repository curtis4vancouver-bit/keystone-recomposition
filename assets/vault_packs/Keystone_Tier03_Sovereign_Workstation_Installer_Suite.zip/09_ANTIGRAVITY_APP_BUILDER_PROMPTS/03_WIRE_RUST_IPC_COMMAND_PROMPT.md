# Prompt 03: Wire Typed Rust Command

```text
In src-tauri/src/main.rs, create a new #[tauri::command] function named "[COMMAND_NAME]" that performs [ACTION]. Register in generate_handler![] and call from app.js.
```
