# Prompt 02: Add New Tab to Command Center

```text
In tauri_command_center_starter/, add a new navigation tab named "[TAB_NAME]". Style with our obsidian glassmorphic card tokens and wire click handler in app.js.
```
