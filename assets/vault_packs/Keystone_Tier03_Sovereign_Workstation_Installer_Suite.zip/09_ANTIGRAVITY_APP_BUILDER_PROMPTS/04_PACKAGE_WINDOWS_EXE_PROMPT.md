# Prompt 04: Package Standalone Windows .EXE

```text
Run `npm run tauri build` to compile the single-file NSIS standalone executable.
```
