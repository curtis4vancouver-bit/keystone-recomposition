# QuickStart: Build Your Standalone Windows .EXE in 10 Minutes

## Prerequisites
1. **Rust & Cargo**: Download and run `rustup-init.exe` from [rust-lang.org](https://www.rust-lang.org).
2. **Visual Studio C++ Build Tools**: In the Visual Studio Installer, ensure **Desktop development with C++** is checked.
3. **Node.js**: Install Node.js LTS (v18+ or v20+) from [nodejs.org](https://nodejs.org).

---

## Step 1: Open the Starter Workspace
Open your terminal in `tauri_command_center_starter/`:

```powershell
cd tauri_command_center_starter
npm install
```

---

## Step 2: Run in Live Development Mode
Launch the live native window:

```powershell
npm run tauri dev
```

A native dark-luxury Windows window opens immediately! Edit `src/index.html` or `src/styles.css` and watch changes reflect live in real time.

---

## Step 3: Compile Your Single Standalone .EXE
When you are ready to distribute your application:

```powershell
npm run tauri build
```

The Rust compiler runs Link-Time Optimization (LTO) and bundles your application into a single standalone installer located at:
`target/release/bundle/nsis/CommandCenter_1.0.0_x64-setup.exe`

Give this file to clients, teammates, or members — it runs natively with zero Node, Python, or dependency requirements!
