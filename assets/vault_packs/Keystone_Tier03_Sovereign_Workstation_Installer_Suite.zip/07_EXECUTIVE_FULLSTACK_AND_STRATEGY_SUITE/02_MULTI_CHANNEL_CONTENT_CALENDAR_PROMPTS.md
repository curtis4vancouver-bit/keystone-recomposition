# 02 — 30-Day Multi-Channel Content Engine & Editorial Calendar Prompts (Tier 03)

Matches **Video Module `V06`** and **Breakdown Sheet `PDF-12`**.

## Copy-Paste Prompt: Generate a 12-Episode YouTube, Short & Blog Production Roadmap
```text
Read 01_Brain_Rules/MY_BRAND_RULES.md. Create a 12-Episode Content & Lead-Generation Master Plan and save it to 00_30DAY_CONTENT_ROADMAP.md.

For each of the 12 episodes, define:
1. High-CTR YouTube Long-Form Title (<62 chars) & Thumbnail Hook (3-5 words)
2. The Core Problem Solved & Lead Magnet / Offer Bridge
3. Companion 30-Second YouTube Short Hook (linking back to the full episode)
4. Companion SEO Blog Article Title & Primary Search Keyword.
```
