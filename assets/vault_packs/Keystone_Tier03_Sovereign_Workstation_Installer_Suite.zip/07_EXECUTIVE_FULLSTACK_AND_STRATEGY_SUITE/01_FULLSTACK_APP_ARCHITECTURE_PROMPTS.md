# 01 — Executive Full-Stack App & Interactive Tool Builder Prompts (Tier 03)

Matches **Video Module `V06`** and **Breakdown Sheets `PDF-10` & `PDF-11`**.

Use these Copy-Paste Prompts inside **Google Antigravity** to build interactive calculators, lead magnets, client portals, and multi-tab web dashboards that turn your website visitors into high-ticket leads.

---

## Copy-Paste Prompt #1: Build an Interactive ROI / Project Calculator Web App
```text
Read 01_Brain_Rules/MY_BRAND_RULES.md and 03_Website_Builder/starter_design_tokens.css.
Build a self-contained, interactive Calculator / Estimator Web App for my target customers and save it to 03_Website_Builder/interactive_calculator_app.html.

Requirements:
1. Style with #04070d Obsidian cards (18px radius), #d4af37 Sovereign Gold sliders/buttons (9999px pill radius), and #38bdf8 Luminous Baby Blue live metric readouts.
2. Include 3 to 4 interactive inputs (sliders or dropdowns) that calculate an instant visual estimate or roadmap on screen in real time.
3. Include a primary CTA button at the bottom inviting the user to book a consultation or request a custom breakdown.
```

## Copy-Paste Prompt #2: Build a 6-Tab Executive Client Portal / Resource Hub Page
```text
Read 01_Brain_Rules/MY_BRAND_RULES.md. Build a responsive 6-Tab Client Resource & Course Portal HTML page (03_Website_Builder/client_resource_portal.html) where clicking each pill tab smoothly switches between:
- Tab 1: Quick-Start Checklist
- Tab 2: Video Training Library
- Tab 3: Templates & Downloads
- Tab 4: Case Studies & Comparison Matrix
- Tab 5: FAQ & Troubleshooting
- Tab 6: Book a Strategy Call
```
