// Keystone Sovereign Command Center Frontend Controller
// Calls native Rust commands via window.__TAURI__.core.invoke with graceful browser fallback.

function logTerminal(message, type = 'info') {
  const term = document.getElementById('terminal-body');
  if (!term) return;
  const line = document.createElement('div');
  line.className = `term-line ${type}`;
  const now = new Date().toLocaleTimeString();
  line.textContent = `[${now}] ${message}`;
  term.appendChild(line);
  term.scrollTop = term.scrollHeight;
}

function clearTerminal() {
  const term = document.getElementById('terminal-body');
  if (term) term.innerHTML = '';
}

function switchTab(tabId) {
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));

  event.target.classList.add('active');
  const activePanel = document.getElementById(`tab-${tabId}`);
  if (activePanel) activePanel.classList.add('active');
  logTerminal(`Switched view to tab '${tabId}'`, 'info');
}

// Check native system status
async function loadSystemStatus() {
  if (window.__TAURI__ && window.__TAURI__.core) {
    try {
      const status = await window.__TAURI__.core.invoke('get_system_status');
      document.getElementById('val-memory').textContent = `${status.memory_mb.toFixed(1)} MB`;
      document.getElementById('sys-status-badge').textContent = status.status;
      logTerminal(`Connected to Rust Core (${status.app_name} v${status.version})`, 'success');
    } catch (err) {
      logTerminal(`Error fetching system status: ${err}`, 'info');
    }
  } else {
    logTerminal(`Running in Web Browser mode. Native Rust commands simulated.`, 'cyan');
  }
}

// Run 1-click workflow task
async function runTask(taskName) {
  logTerminal(`Executing task '${taskName}'...`, 'cyan');
  if (window.__TAURI__ && window.__TAURI__.core) {
    try {
      const result = await window.__TAURI__.core.invoke('run_workflow_task', { taskName });
      logTerminal(result.output_log, 'success');
    } catch (err) {
      logTerminal(`Task failed: ${err}`, 'info');
    }
  } else {
    // Browser simulation
    setTimeout(() => {
      const mockLogs = {
        research: '[RESEARCH] Scouted 3 authoritative developer sources. Briefing saved.',
        script: '[SCRIPT] Generated 3 sequential 10-second Google Flow prompts (~20w).',
        audit: '[AUDIT] Verified 18-24w pacing, #04070d design tokens, and FAQ JSON-LD.',
        crm: '[CRM] Validated recipient MX records. Locked-logo HTML ready.',
      };
      logTerminal(mockLogs[taskName] || `Task '${taskName}' completed successfully.`, 'success');
    }, 200);
  }
}

// Workspace diagnostic scanner
async function checkHealth() {
  const path = document.getElementById('workspace-path-input').value || 'My_AI_Brain';
  logTerminal(`Running health scan on folder: ${path}...`, 'cyan');
  const resultBox = document.getElementById('diagnostic-results');

  if (window.__TAURI__ && window.__TAURI__.core) {
    try {
      const report = await window.__TAURI__.core.invoke('check_folder_health', { folderPath: path });
      document.getElementById('val-health').textContent = `${report.health_score.toFixed(0)}%`;
      resultBox.innerHTML = `<strong>Scan Status:</strong> ${report.message}<br/>Rules File: ${report.rules_file_found ? 'VALID' : 'MISSING'} | Scripts: ${report.total_scripts} | Exports: ${report.total_exports}`;
      logTerminal(report.message, report.rules_file_found ? 'success' : 'info');
    } catch (err) {
      resultBox.innerHTML = `Scan error: ${err}`;
      logTerminal(`Health check error: ${err}`, 'info');
    }
  } else {
    setTimeout(() => {
      document.getElementById('val-health').textContent = '100%';
      resultBox.innerHTML = `<strong>Scan Complete (Simulation):</strong> Workspace '${path}' healthy! 01_Brain_Rules/AGENTS.md verified with 12 scripts on disk.`;
      logTerminal(`Workspace '${path}' verified at 100% health score.`, 'success');
    }, 200);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  loadSystemStatus();
});
