# 02 — Google Flow ~20-Word Video Prompt Pack & Manual MP4 Export Guide

Matches **Video Module `V02`** and **Breakdown Sheet `PDF-02`**.

When creating 10-second AI video clips inside **Google Flow**, the #1 mistake beginners make is pasting long, rambling paragraphs of dialogue. If a 10-second clip has 40+ words, the speaker rushes, the audio cuts off mid-sentence, or the visuals lose focus.

---

## The ~20-Word Pacing Formula (18 to 24 Spoken Words per 10-Second Clip)

At a natural, confident speaking cadence of **130 to 145 words per minute**, a **10-second video clip** comfortably fits **~20 words (strictly 18 to 24 spoken words)**:
- **Seconds `0.0s – 0.5s`**: Clean camera settle and natural breath in.
- **Seconds `0.5s – 9.0s`**: **18 to 24 spoken words** delivered clearly with natural pauses.
- **Seconds `9.0s – 10.0s`**: Clean visual finish so you can cut smoothly to your next clip in any video editor (CapCut, Premiere, or DaVinci Resolve) without clipping the last word.

### Anatomy of Every Google Flow Scene Prompt
Each prompt you paste into Google Flow combines **4 simple elements**:
1. **Subject & Wardrobe**: Who is on screen and what they are wearing (keep the description identical across clips for visual consistency).
2. **Setting & Lighting**: Where the scene takes place (e.g., modern dark oak studio with warm gold and cool blue accent lighting).
3. **Camera & Action**: Natural hand gesture and subtle camera movement (e.g., slow 35mm push-in, calm two-handed explanation gesture).
4. **Spoken Dialogue (~20 Words)**: The exact 18–24 word spoken line in quotation marks.

---

## Copy-Paste Antigravity Prompt #1: Generate a 10-Clip (~20 Words/Clip) Script for Google Flow
Paste this into Antigravity to generate a complete 10-scene video script (approx. 1 minute 40 seconds total) ready to paste into Google Flow:

```text
Read 01_Brain_Rules/MY_BRAND_RULES.md. Write a 10-clip video script on the topic: "[INSERT YOUR VIDEO TOPIC HERE]" and save it to 02_Video_Prompts/Episode_01_Flow_Prompts.md.

Follow these strict rules for every clip:
1. Each clip is a 10-second scene for Google Flow.
2. The spoken dialogue for each clip MUST be ~20 words (strictly between 18 and 24 words). Print the exact word count in brackets after each spoken line.
3. For each clip (Clip 01 through Clip 10), provide a single ready-to-copy "GOOGLE FLOW PROMPT BOX" that includes:
   - Consistent presenter & wardrobe description
   - Consistent studio background & lighting description
   - Natural camera movement & hand gesture
   - The exact 18-24 word spoken line in quotes.
```

---

## Copy-Paste Antigravity Prompt #2: Generate 5 Companion Visual B-Roll Prompts for Google Flow
```text
Based on 02_Video_Prompts/Episode_01_Flow_Prompts.md, write 5 cinematic 10-second B-Roll prompts (B-Roll 01 to B-Roll 05) with zero spoken dialogue that visually illustrate the key points of my script. Format each prompt inside a clean code block so I can copy and paste it directly into Google Flow, then layer the downloaded MP4 clips over my main video track.
```

---

## Step-by-Step: Pasting into Google Flow & Exporting Your MP4 Clips

1. **Open Google Flow**: Sign into Google Flow in your browser and create a **New Project**.
2. **Set Your Aspect Ratio**: Choose **16:9 Landscape** for YouTube long-form videos (or **9:16 Vertical** for YouTube Shorts / Reels).
3. **Copy & Paste Scene by Scene**:
   - Open `02_Video_Prompts/Episode_01_Flow_Prompts.md` in Antigravity.
   - Copy the **Clip 01 Google Flow Prompt** and paste it into the Google Flow prompt box.
   - Optional: Upload a consistent reference photo of your studio background or presenter if you want identical framing across clips.
   - Click **Generate** and wait for the 10-second preview tile to finish rendering.
4. **Review & Export / Download MP4**:
   - Play back the generated 10-second clip inside Google Flow to verify clear audio and smooth visuals.
   - Hover over the finished video tile and click **Export / Download MP4** (select **1080p**).
   - Save each downloaded file into your project folder with a clean sequential filename:
     * `Clip_01.mp4`, `Clip_02.mp4`, `Clip_03.mp4` ... `Clip_10.mp4`
     * `BRoll_01.mp4`, `BRoll_02.mp4` ... `BRoll_05.mp4`
5. **Drop into Your Video Editor**:
   - Drag `Clip_01.mp4` through `Clip_10.mp4` onto **Video Track 1** in order.
   - Place `BRoll_01.mp4` through `BRoll_05.mp4` on **Video Track 2** over transition points, add a subtle background music track at `-18 dB`, and export your finished master video!
