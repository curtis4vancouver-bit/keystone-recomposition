# 02 — Google Flow ~20-Word Video Prompt Pack

## The ~20-Word Pacing Rule for 10-Second Clips
Keep every 10-second scene dialogue strictly between **18 and 24 spoken words (~20 words)**.
- `0.0s – 0.5s`: Natural settle and breath in.
- `0.5s – 8.8s`: 18–24 spoken words delivered clearly.
- `8.8s – 10.0s`: Clean settle and breath out with zero cutoff.

## Master Scene Generator Prompt (Run in Antigravity)
```text
Using my rules in 01_Brain_Rules/AGENTS.md, write 3 sequential 10-second Google Flow video scene prompts about [INSERT TOPIC]. Keep each spoken dialogue strictly between 18 and 24 plain words (~20 words), and format each clip on a single line:
Presenter says: "[18-24 spoken words]" Camera: With reference to me avatar, wearing cloth_1 with background background_1, [35mm cinema framing & natural gesture]
```

## Manual 1080p MP4 Export Checklist
1. Attach your 3 reference photos in Google Flow: `Me` Avatar + `cloth_1` Outfit + `background_1` Studio.
2. Paste Scene 1 and click **Generate**.
3. Review playback and click **Export / Download MP4 (1080p)**.
4. Save into `04_Exports/Clip_01.mp4`.
