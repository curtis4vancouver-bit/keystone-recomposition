# DNS/MX Lead Verification Gate

1. Never send cold outreach to generic desks (`info@`, `support@`, `sales@`).
2. Verify domain MX records via DNS lookup before adding to `prospect_tracker.md`.
3. Target named executives, partners, and decision-makers.
4. Always include valid postal address and 1-click unsubscribe option.
