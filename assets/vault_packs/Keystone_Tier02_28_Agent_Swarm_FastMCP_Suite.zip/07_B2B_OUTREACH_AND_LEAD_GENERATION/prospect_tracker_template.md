# B2B Prospect & Partner Tracker

| Prospect Name | Company | Verified Email | MX Verified | Date Contacted | Status | Notes |
|---|---|---|---|---|---|---|
| Example Lead | Sovereign Corp | lead@sovereign.com | YES | 2026-11-01 | Initial Sent | Interested in video pipeline |
