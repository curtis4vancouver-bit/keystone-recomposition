# Keystone AI Protocols — Tier 02 Multi-Agent Brain & B2B Outreach Suite

Welcome to **Tier 02 ($200 Suite)** by **Wayne Stevenson** (`keystonerecomposition.com/ai-protocols/`).

## Included in Your Tier 02 Pack
- **Everything from Tier 01** (`01`–`05` Antigravity Brain Setup, Google Flow ~20-Word Video Prompt Pack, Website Builder Prompts, YouTube Channel Setup Prompts, and Gutenberg/CSS Starter Files).
- **`06_MULTI_AGENT_ROLE_PROMPTS/`**:
  * `README_MULTI_AGENT_BRAIN_ROLES.md`
  * `01_RESEARCHER_AND_FACT_CHECKER_PROMPTS.md`
  * `02_SCRIPT_AND_ARTICLE_WRITER_PROMPTS.md`
  * `03_CODE_AUDITOR_AND_QA_PROMPTS.md`
  * `04_EMAIL_OUTREACH_AND_CRM_PROMPTS.md`
