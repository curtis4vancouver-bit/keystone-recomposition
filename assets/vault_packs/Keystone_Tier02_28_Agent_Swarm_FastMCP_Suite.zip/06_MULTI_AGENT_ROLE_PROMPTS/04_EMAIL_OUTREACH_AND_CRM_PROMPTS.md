# Role 04 — B2B Email Outreach & Locked Logo HTML Template Prompt

Matches **Video Module `V05`** and **Breakdown Sheets `PDF-08` & `PDF-09`**.

## Copy-Paste Antigravity Prompt: Build My Locked Logo HTML Email & Prospect Tracker
```text
Act as my B2B Partnership & Email Outreach Specialist inside My_AI_Brain/.
Read 01_Brain_Rules/MY_BRAND_RULES.md.

Create two files inside a new folder named 05_Outreach_CRM/:
1. 05_Outreach_CRM/locked_logo_email_template.html:
   - A responsive dark-luxury HTML email shell (#04070d background, #d4af37 gold border) with a Locked Top Header Logo banner, a customizable middle message section, a 9999px Gold Pill CTA button, and a Locked Bottom Executive Signature with CASL/CAN-SPAM unsubscribe wording.
2. 05_Outreach_CRM/prospect_tracker.md:
   - A clean CRM table tracking Prospect Name, Company, Verified Email, Niche, Date Contacted, Follow-Up Status, and Notes (with a rule to never message noreply@ or generic government/municipal desks).
```
