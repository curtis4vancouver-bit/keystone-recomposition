# Role 04 — B2B Email Outreach & CRM Prompt

```text
Act as my B2B Outreach Specialist. Read 01_Brain_Rules/AGENTS.md.
Create two files inside 05_Outreach_CRM/:
1. locked_logo_email_template.html: Dark-luxury responsive HTML email (#04070d, #d4af37) with header logo, 9999px Gold Pill CTA, and CASL/CAN-SPAM footer.
2. prospect_tracker.md: Clean CRM table tracking Prospect, Company, Verified Email, Date, Status, and Notes.
```
