# Role 02 — Master Script & Luxury Blog Writer Prompt

```text
Act as my Script & Article Writer inside My_AI_Brain/. Read 01_Brain_Rules/AGENTS.md and 02_Video_Prompts/Research_Brief_01.md.
Produce two synchronized deliverables:
1. 02_Video_Prompts/Episode_01_Flow_Prompts.md: 10 sequential 10s Google Flow prompts (strictly 18-24 spoken words per clip) + 5 visual B-roll prompts.
2. 03_Website_Builder/Episode_01_Blog_Post.html: 1,200-word dark-luxury Gutenberg article (#04070d Obsidian, #d4af37 Gold, #38bdf8 Cyan) with comparison table and FAQPage JSON-LD.
```
