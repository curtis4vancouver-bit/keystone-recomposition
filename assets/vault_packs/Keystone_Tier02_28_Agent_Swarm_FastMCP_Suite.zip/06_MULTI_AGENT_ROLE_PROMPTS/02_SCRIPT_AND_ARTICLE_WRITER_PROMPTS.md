# Role 02 — The ~20-Word Script & Luxury Blog Writer Agent Prompt

Paste this prompt into Antigravity after `Research_Brief_01.md` is saved:

```text
Act as my Master Script & Article Writer inside My_AI_Brain/.
Read 01_Brain_Rules/MY_BRAND_RULES.md and 02_Video_Prompts/Research_Brief_01.md.

Produce two synchronized deliverables:
1. Save 02_Video_Prompts/Episode_01_Flow_Prompts.md containing 10 sequential 10-second Google Flow clip prompts (strictly 18-24 spoken words per clip) + 5 visual B-roll prompts.
2. Save 03_Website_Builder/Episode_01_Blog_Post.html containing the companion 1,200-word dark-luxury Gutenberg article (#04070d Obsidian, #d4af37 Gold, #38bdf8 Baby Blue) with a comparison table and FAQ schema.
```
