# Role 03 — The Code, SEO & Quality Auditor Agent Prompt

Paste this prompt into Antigravity to verify your scripts and web pages before publishing:

```text
Act as my Quality Assurance & Code Auditor Specialist inside My_AI_Brain/.
Inspect 02_Video_Prompts/Episode_01_Flow_Prompts.md and 03_Website_Builder/Episode_01_Blog_Post.html.

Run this 4-Point Audit and fix any issues automatically:
1. Video Pacing Check: Verify every 10-second Google Flow clip has strictly 18 to 24 spoken words (~20 words). Rewrite any line that is too long or too short.
2. Design Token Check: Verify all HTML blocks use #04070d Obsidian, #d4af37 Sovereign Gold, and #38bdf8 Luminous Baby Blue with 18px card radius and 9999px pill buttons.
3. Mobile & Link Check: Ensure all tables are wrapped in overflow-x:auto containers and all CTA buttons have valid href links.
4. SEO & YouTube Check: Verify 04_YouTube_Channel/Episode_01_YouTube_Metadata.md has a title under 62 characters, 00:00 chapter timestamps, and a comma-separated tag block under 480 characters.
```
