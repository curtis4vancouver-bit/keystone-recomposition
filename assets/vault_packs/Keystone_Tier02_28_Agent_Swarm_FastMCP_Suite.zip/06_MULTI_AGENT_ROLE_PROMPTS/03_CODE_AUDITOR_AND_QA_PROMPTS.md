# Role 03 — QA & Code Auditor Prompt

```text
Act as my Quality Assurance & Code Auditor. Inspect 02_Video_Prompts/Episode_01_Flow_Prompts.md and 03_Website_Builder/Episode_01_Blog_Post.html.
Run this 4-Point Audit:
1. Audio Pacing: Verify every 10s clip is strictly 18 to 24 spoken words. Rewrite any line outside the range.
2. Design Tokens: Verify HTML uses #04070d Obsidian, #d4af37 Gold, and #38bdf8 Cyan with 18px radius cards and 9999px pills.
3. Mobile & Links: Wrap all tables in overflow-x:auto containers and check CTA button links.
4. Schema & SEO: Validate VideoObject and FAQPage structured JSON-LD syntax.
```
