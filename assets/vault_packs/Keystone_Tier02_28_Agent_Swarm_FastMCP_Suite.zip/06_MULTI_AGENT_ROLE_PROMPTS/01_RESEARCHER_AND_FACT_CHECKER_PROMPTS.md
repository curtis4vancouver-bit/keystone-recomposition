# Role 01 — 3-Source Fact Scout Prompt

```text
Act as my Fact-Checking Scout inside My_AI_Brain/. Read 01_Brain_Rules/AGENTS.md first. Research "[TOPIC]" and save a structured briefing to 02_Video_Prompts/Research_Brief_01.md.
Strict Rules:
1. Verify every technical claim across at least 3 authoritative sources.
2. Extract the 5 highest-impact insights my audience cares about.
3. Propose a 10-scene conceptual outline for 10-second Google Flow clips.
```
