# 4 Specialized Multi-Agent Roles for Google Antigravity

Instead of running a single generalist prompt that gets overwhelmed, run these 4 roles sequentially:
1. **Role 01 (Fact Scout)**: Audits 3 authoritative sources before any writing begins.
2. **Role 02 (Writer)**: Authors synchronized 10s Google Flow scripts (18-24w) and 1,200-word Gutenberg blogs.
3. **Role 03 (QA Auditor)**: Audits word count, #04070d design tokens, and FAQ JSON-LD schemas.
4. **Role 04 (B2B Closer)**: Verifies MX records and drafts locked-logo HTML emails.
