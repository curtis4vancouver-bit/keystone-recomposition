# Tier 02 — Multi-Agent Brain Role Prompts for Google Antigravity

Matches **Video Modules `V04` & `V05`** and **Breakdown Sheets `PDF-06` through `PDF-09`**.

Instead of asking a single generic chat thread to research, write, code, audit, and write outreach emails all at once (which causes context overload and sloppy output), Tier 02 gives you **4 Dedicated Copy-Paste Specialist Role Prompts** inside your Antigravity AI Brain:

1. `01_RESEARCHER_AND_FACT_CHECKER_PROMPTS.md` — Deep 3-source topic research & outline verification before you write a script or article.
2. `02_SCRIPT_AND_ARTICLE_WRITER_PROMPTS.md` — Converts verified research into 10-clip (~20-word) Google Flow scripts and companion SEO blog posts.
3. `03_CODE_AUDITOR_AND_QA_PROMPTS.md` — Audits your website HTML/CSS, JSON-LD schema, and mobile layout before publishing.
4. `04_EMAIL_OUTREACH_AND_CRM_PROMPTS.md` — Generates professional B2B partner outreach emails, Locked Top-and-Bottom Logo HTML email templates, and a clean JSON/Markdown lead tracker.
