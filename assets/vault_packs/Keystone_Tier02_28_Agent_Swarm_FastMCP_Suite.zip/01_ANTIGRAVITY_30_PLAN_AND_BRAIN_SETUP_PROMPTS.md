# 01 — Google Antigravity Plan & 4-Folder Brain Setup

1. Launch **Google Antigravity** and activate the **$30/mo Pro Plan** for full workspace memory.
2. Create a folder named `My_AI_Brain` on your drive.
3. In Antigravity, click **File -> Open Folder** and select `My_AI_Brain`.
4. Copy and paste **Setup Prompt #1** below into the chat:

```text
You are my Lead AI Systems Architect inside Google Antigravity. Verify or create my 4-folder AI Brain workspace: 01_Brain_Rules, 02_Video_Prompts, 03_Website_Builder, and 04_YouTube_Channel. Always read 01_Brain_Rules/AGENTS.md at the start of every session so you remember my brand voice, target audience, and ~20-word Google Flow video prompt rules. Reply with a 3-bullet confirmation when ready.
```

5. Next, run **Setup Prompt #2** to fill in your brand identity:

```text
Read my starter files. Interview me with 5 simple questions about my company name, target audience, core offer, website link, and preferred tone of voice. When I answer, write my complete profile into 01_Brain_Rules/AGENTS.md and generate my first 10 video episode topics in 02_Video_Prompts/Topic_Roadmap.md.
```
