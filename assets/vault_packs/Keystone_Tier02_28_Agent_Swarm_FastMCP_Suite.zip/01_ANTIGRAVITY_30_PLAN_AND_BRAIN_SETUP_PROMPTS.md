# 01 — How to Get the $30/mo Antigravity Plan & Build Your AI Brain Folder

Welcome to **Keystone AI Protocols — Tier 01 Blueprint** by **Wayne Stevenson** (`keystonerecomposition.com/ai-protocols/`).

This guide walks you step-by-step through activating your **$30/mo Antigravity workspace** and organizing your **Local AI Brain Folder** so Antigravity remembers your brand voice, writes your ~20-word Google Flow video prompts, builds your website pages, and formats your YouTube channel metadata automatically.

---

## Step 1: Activate Your $30/mo Antigravity Plan & Open Your Workspace
1. Install and launch **Google Antigravity** on your desktop computer and activate the **$30/mo Pro Plan** so you have full access to workspace file creation, context memory, and multi-file editing.
2. Create a clean folder on your computer named `My_AI_Brain` (for example, inside your `Documents` or `Desktop` folder).
3. In Antigravity, click **File -> Open Folder** and select `My_AI_Brain`.

---

## Step 2: Visual AI Brain Folder Setup Diagram (Matches `PDF-01`)

Your AI Brain works because every rule, video script template, website layout, and YouTube upload default lives in a clean 4-pillar folder structure that Antigravity reads automatically at the start of every chat:

```text
My_AI_Brain/
├── 00_MASTER_BRAIN_INDEX.md                 <-- Master map of your brand, niche & goals
├── 01_Brain_Rules/
│   └── MY_BRAND_RULES.md                    <-- Tone of voice, target audience & style rules
├── 02_Video_Prompts/
│   ├── 20_WORD_FLOW_TEMPLATE.md             <-- ~20-word (18-24 word) 10s clip pacing formula
│   └── Episode_01_Flow_Prompts.md           <-- Generated 10-second scene prompts for Google Flow
├── 03_Website_Builder/
│   ├── WEBSITE_PROMPT_TEMPLATE.md           <-- Landing page & article builder prompts
│   ├── gutenberg_starter_blocks.html        <-- Ready-to-paste dark-luxury HTML blocks
│   └── starter_design_tokens.css            <-- Clean Obsidian, Gold & Baby Blue CSS stylesheet
└── 04_YouTube_Channel/
    ├── CHANNEL_DEFAULTS_TEMPLATE.md         <-- Brand Account bio, upload defaults & links
    └── Episode_01_YouTube_Metadata.md       <-- Titles, timestamps, 480-char tags & pinned comment
```

```mermaid
flowchart TD
    Root["📁 My_AI_Brain/ (Workspace Root)"]
    Idx["📄 00_MASTER_BRAIN_INDEX.md"]
    F1["📂 01_Brain_Rules/
MY_BRAND_RULES.md"]
    F2["📂 02_Video_Prompts/
20_WORD_FLOW_TEMPLATE.md"]
    F3["📂 03_Website_Builder/
WEBSITE_PROMPT_TEMPLATE.md"]
    F4["📂 04_YouTube_Channel/
CHANNEL_DEFAULTS_TEMPLATE.md"]

    Root --> Idx
    Root --> F1
    Root --> F2
    Root --> F3
    Root --> F4
```

---

## Step 3: 3 Copy-Paste Prompts to Build Your AI Brain in Antigravity

Copy and paste these 3 prompts directly into your Antigravity chat window one at a time.

### Copy-Paste Prompt #1: Auto-Create the 4-Folder AI Brain Structure
```text
Please create my complete Local AI Brain directory structure inside this workspace:
1. Create the folders: 01_Brain_Rules/, 02_Video_Prompts/, 03_Website_Builder/, and 04_YouTube_Channel/.
2. Create 00_MASTER_BRAIN_INDEX.md linking to all four folders with a clean summary of my workspace.
3. Inside 01_Brain_Rules/MY_BRAND_RULES.md, create a structured template where I can fill in my Brand Name, Target Audience, Core Offer, Website URL, YouTube Channel Name, and 5 Tone-of-Voice Rules (clear, authoritative, practical, zero fluff).
```

### Copy-Paste Prompt #2: Interview Me & Lock In My Brand Voice
```text
Read 01_Brain_Rules/MY_BRAND_RULES.md. Ask me 5 quick questions about my business or content niche, my target viewer/customer, the main problem I solve, and my website or channel goal. Once I answer, update 01_Brain_Rules/MY_BRAND_RULES.md and 00_MASTER_BRAIN_INDEX.md so you remember my brand rules in every future session.
```

### Copy-Paste Prompt #3: Weekly Brain Memory & Link Audit
```text
Scan all markdown files inside My_AI_Brain/. Update 00_MASTER_BRAIN_INDEX.md with links to every new video script in 02_Video_Prompts/, every landing page or blog post in 03_Website_Builder/, and every YouTube metadata sheet in 04_YouTube_Channel/ so my Brain stays 100% organized.
```
