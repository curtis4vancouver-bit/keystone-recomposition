# 04 — YouTube Channel Setup, Upload Defaults & SEO Prompt Pack

Matches **Video Module `V03`** and **Breakdown Sheets `PDF-03` & `PDF-05`**.

---

## Part 1: Setting Up Your YouTube Brand Account & Upload Defaults
1. Sign into YouTube Studio (`https://studio.youtube.com`).
2. Under **Settings -> Channel -> Basic Info**, set your country of residence and paste your core **Channel Keywords** (generated with Prompt #1 below).
3. Under **Settings -> Channel -> Feature Eligibility**, complete phone verification (Intermediate features) so you can upload **custom 16:9 thumbnails** and videos longer than 15 minutes.
4. Under **Settings -> Upload Defaults**, paste your permanent footer links (website URL, newsletter/lead magnet link, and chapter placeholder) so you never have to re-type them on every upload.
5. **Altered / Synthetic Content Disclosure**: When uploading videos containing AI-generated avatars or realistic synthetic scenes in YouTube Studio, check **"Yes"** under the *Altered content* section in Details so your channel stays 100% compliant with YouTube policy.

---

## Copy-Paste Antigravity Prompt #1: Complete YouTube Channel Positioning & Upload Defaults
```text
Read 01_Brain_Rules/MY_BRAND_RULES.md. Create my complete YouTube Channel Setup Kit and save it to 04_YouTube_Channel/My_Channel_Setup_Kit.md, including:
1. 5 Channel Name & @Handle ideas
2. An authoritative, high-converting 150-word Channel Description ("About" tab) with my website link in the first 2 lines
3. Channel Banner tagline (under 8 words)
4. 25 comma-separated Channel Keywords (under 480 characters total)
5. My permanent "Upload Defaults" description footer template.
```

## Copy-Paste Antigravity Prompt #2: Episode YouTube Title, Description, Chapters & 480-Char Tags
```text
Read my video script in 02_Video_Prompts/Episode_01_Flow_Prompts.md. Generate the complete YouTube Studio upload package and save it to 04_YouTube_Channel/Episode_01_YouTube_Metadata.md:
1. 5 high-CTR YouTube Titles (under 62 characters each) + 3 Thumbnail Text Hook ideas (3-5 bold words)
2. Full SEO Video Description (first 2 lines hooking the viewer + my website link, 300-word summary, and 00:00 chapter timestamps matching my 10-second clips)
3. A comma-separated Tag block strictly between 440 and 480 characters total
4. A Pinned Comment with a question to drive viewer comments and a link to my website.
```

## Copy-Paste Antigravity Prompt #3: Companion YouTube Short & Related Video Bridge
```text
Read 02_Video_Prompts/Episode_01_Flow_Prompts.md. Write a 3-clip (30-second total, 9:16 vertical) YouTube Short script where each 10-second clip is ~20 words (18-24 words). End Clip 03 with a clear verbal callout pointing viewers to click the "Related Video" link at the bottom of the Short player to watch the full episode.
```
