# 04 — YouTube Channel Setup & 480-Character Tag Stacks

## Episode YouTube Metadata Prompt
```text
Read 02_Video_Prompts/Episode_01_Flow_Prompts.md. Generate my YouTube Studio upload package in 04_YouTube_Channel/Episode_01_Metadata.md:
1. 5 High-CTR YouTube Titles (<62 chars) & 3 Thumbnail text hook ideas (3-5 words)
2. 300-word SEO Description with website link in first 2 lines and 00:00 chapter timestamps
3. Comma-separated tag block strictly between 440 and 480 characters total
4. Pinned comment question to drive viewer comments and link to landing page.
```

## Companion 30s Short Bridge Prompt
```text
Write a 3-clip (30s total, 9:16 vertical) YouTube Short script based on Episode 01. Keep each 10s clip to ~20 words (18-24w). End Clip 3 with: "Click the Related Video link right below to watch our full masterclass." Save to 02_Video_Prompts/Episode_01_Short.md.
```
