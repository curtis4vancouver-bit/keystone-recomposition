# 03 — Website, Landing Page & Luxury Blog Prompt Pack

Matches **Video Module `V03`** and **Breakdown Sheet `PDF-04`**.

Your starter pack includes two ready-to-use web design files:
- `gutenberg_starter_blocks.html` — Ready-to-paste dark-luxury HTML layout (`#04070d` Obsidian background, `#d4af37` Sovereign Gold accents, `#38bdf8` Luminous Baby Blue highlights, `18px` rounded cards, and `9999px` pill CTA buttons).
- `starter_design_tokens.css` — Clean CSS variables and utility classes for WordPress, Next.js, or standalone HTML sites.

---

## Copy-Paste Antigravity Prompt #1: Build a High-Converting Dark-Luxury Landing Page
```text
Read 01_Brain_Rules/MY_BRAND_RULES.md and 03_Website_Builder/starter_design_tokens.css.
Build a complete, responsive, single-file HTML landing page (or WordPress Gutenberg Custom HTML block) for my core offer and save it to 03_Website_Builder/landing_page_v1.html.

Design Requirements:
1. Use our strict 3-color luxury palette: Obsidian (#04070d) background, Sovereign Gold (#d4af37) primary headlines and CTA buttons, and Luminous Baby Blue (#38bdf8) badges and links.
2. Use 18px border-radius on all cards and 9999px pill styling on all buttons.
3. Include:
   - Hero section with badge, headline, subheadline, and primary CTA button
   - 3-Column Feature/Benefit cards
   - A clean 3-column Comparison Matrix Table
   - FAQ accordion section and footer CTA.
```

## Copy-Paste Antigravity Prompt #2: Turn Any Video Script into an SEO Blog Article + Comparison Table
```text
Read my video script in 02_Video_Prompts/Episode_01_Flow_Prompts.md and the HTML template in 03_Website_Builder/gutenberg_starter_blocks.html.
Write a comprehensive, scannable 1,200-word companion blog post formatted in clean WordPress Gutenberg HTML blocks and save it to 03_Website_Builder/Episode_01_Blog_Post.html.
Include:
1. A responsive 16:9 YouTube video embed container at the top
2. Key takeaways callout box
3. An 18px rounded Comparison Table summarizing the core framework
4. FAQ section with FAQPage JSON-LD schema at the bottom.
```

## Copy-Paste Antigravity Prompt #3: Google Search Console Inspection & Indexing Checklist
```text
Read 03_Website_Builder/Episode_01_Blog_Post.html. Generate a pre-publish SEO & Google Search Console checklist for this article including:
1. SEO Title (under 60 characters) with primary keyword first
2. Meta Description (145-158 characters)
3. URL Slug recommendation
4. Article + VideoObject JSON-LD schema snippet ready to paste into the page header so I can paste my published URL into Google Search Console URL Inspection and click "Request Indexing".
```
