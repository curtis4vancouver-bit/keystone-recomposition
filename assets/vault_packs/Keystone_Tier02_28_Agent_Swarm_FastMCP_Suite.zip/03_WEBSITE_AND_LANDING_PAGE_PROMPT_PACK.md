# 03 — Dark-Luxury Website & Blog Prompt Pack

## Design Tokens:
- **Obsidian**: `#04070d`
- **Sovereign Gold**: `#d4af37`
- **Luminous Baby Blue**: `#38bdf8`
- **Cards**: `18px` border-radius
- **Buttons**: `9999px` pill radius

## Copy-Paste Prompt: Generate 1,200-Word SEO Blog Post
```text
Read 02_Video_Prompts/Episode_01_Flow_Prompts.md. Write a 1,200-word companion blog post formatted in clean WordPress Gutenberg HTML blocks and save it to 03_Website_Builder/Episode_01_Blog_Post.html.
Include:
1. 16:9 responsive YouTube embed container
2. Key takeaways callout box
3. 18px rounded comparison table comparing old methods with our standard
4. FAQ accordion section with FAQPage JSON-LD schema markup at the bottom.
```
