# Keystone AI Protocols — Tier 01 AI Video, Website & YouTube Blueprint Pack

Welcome to **Tier 01: Antigravity AI Video & Website Fast-Track Blueprint** by **Wayne Stevenson** (`keystonerecomposition.com/ai-protocols/`).

## Included Files in This Pack
1. `01_ANTIGRAVITY_30_PLAN_AND_BRAIN_SETUP_PROMPTS.md` — Step-by-step guide to the **$30/mo Antigravity plan**, the **Visual AI Brain Setup Diagram**, and **3 Copy-Paste Prompts** that scaffold your `My_AI_Brain/` folder automatically.
2. `02_GOOGLE_FLOW_20_WORD_VIDEO_PROMPT_PACK.md` — The **~20-Word Pacing Formula** (18–24 words per 10-second clip), Copy-Paste Antigravity prompts for 10-scene video scripts + B-roll, and how to **Export / Download MP4s** from Google Flow.
3. `03_WEBSITE_AND_LANDING_PAGE_PROMPT_PACK.md` + `gutenberg_starter_blocks.html` + `starter_design_tokens.css` — Copy-Paste prompts and starter HTML/CSS blocks to build `#04070d` Obsidian & `#d4af37` Gold landing pages and blog posts.
4. `04_YOUTUBE_CHANNEL_SETUP_AND_SEO_PROMPTS.md` — Copy-Paste prompts for setting up your YouTube Brand Account, Upload Defaults, 480-character Tag blocks, AI Disclosure settings, and Short-to-Long Related Video links.
5. `05_BRAIN_FOLDER_STARTER_TEMPLATE/` — Ready-to-use folder structure (`01_Brain_Rules`, `02_Video_Prompts`, `03_Website_Builder`, `04_YouTube_Channel`) to drop straight into your Antigravity workspace.

## Need Personalized Help Setting Up Your Channel or Brain Folder?
Simply hit **Reply** to your welcome email from `keystonerecomposition@gmail.com` and tell us your niche, channel name idea, or what step you are on — our 24/7 AI Teacher & onboarding engine will walk you through it step-by-step!
