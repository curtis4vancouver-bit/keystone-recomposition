# Keystone AI Protocols — Tier 01 Foundation Blueprint Pack ($49.50 USD)
## AI Brain Workspace & Google Flow 10-Second Video Walkthrough
**Author**: Wayne Stevenson (BC Housing Licensed Builder #52603 • Systems Architect)
**Portal**: https://keystonerecomposition.com/ai-protocols/

Welcome to **Tier 01**! Everything in this package is organized so you can activate your **$30/mo Google Antigravity plan**, build your **4-Folder AI Brain**, and export clean **10-second 1080p MP4 clips** in Google Flow.

---

### What Is Inside This Package:
1. **`PDF_Guides/`** (Printable step-by-step setup guides with selectable copy-paste prompt blocks):
   - `KR_T1_01_AI_Brain_Workspace_QuickStart.pdf` — Setting up your 4-folder workspace in Antigravity.
   - `KR_T1_02_AGENTS_MD_Memory_And_Rules_Guide.pdf` — Teaching your AI your brand voice & ~20-word video rules.
   - `KR_T1_03_Google_Flow_Basic_10s_Video_Guide.pdf` — 3-Chip photo reference lock & 1080p MP4 export.
   - `KR_T1_04_Scene_Prompt_Templates_And_Setup_Support.pdf` — 15 Plug-and-play scene templates & 7-day setup support.
   - `KR_T1_00_ALL_4_GUIDES_COMBINED.pdf` — Complete unified master manual.

2. **`Architecture_Diagrams/`**:
   - `Diagram_01_Four_Folder_AI_Brain_And_Flow_Pipeline.svg` and `.png` (High-resolution vector architecture map).

3. **`05_BRAIN_FOLDER_STARTER_TEMPLATE/`**:
   - Pre-scaffolded directory structure ready to drop into your workspace (`01_Brain_Rules`, `02_Video_Prompts`, `03_Website_Builder`, `04_YouTube_Channel`).

4. **Copy-Paste Setup Prompts**:
   - `01_ANTIGRAVITY_30_PLAN_AND_BRAIN_SETUP_PROMPTS.md`
   - `02_GOOGLE_FLOW_20_WORD_VIDEO_PROMPT_PACK.md`
   - `03_WEBSITE_AND_LANDING_PAGE_PROMPT_PACK.md`
   - `04_YOUTUBE_CHANNEL_SETUP_AND_SEO_PROMPTS.md`
   - `gutenberg_starter_blocks.html` (#04070d Obsidian & #d4af37 Gold luxury block)
   - `starter_design_tokens.css` (Clean CSS variables & 9999px pill button tokens).

---

### How to Get Setup Help:
You receive **7 days of guided setup support (up to 3 follow-up questions)**. Simply reply directly to your Welcome Email or visit your member portal at `keystonerecomposition.com/ai-protocols/` with your Buyer UID!
