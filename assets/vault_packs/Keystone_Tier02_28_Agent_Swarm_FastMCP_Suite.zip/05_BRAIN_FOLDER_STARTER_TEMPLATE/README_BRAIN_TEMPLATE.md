# My AI Brain — Starter Folder Structure

Copy these 4 folders into your `My_AI_Brain` workspace:
```text
My_AI_Brain/
├── 01_Brain_Rules/
│   └── AGENTS.md
├── 02_Video_Prompts/
│   └── 20_WORD_FLOW_TEMPLATE.md
├── 03_Website_Builder/
│   └── WEBSITE_PROMPT_TEMPLATE.md
└── 04_YouTube_Channel/
    └── CHANNEL_DEFAULTS_TEMPLATE.md
```
