# Website Builder Template
Use #04070d Obsidian, #d4af37 Sovereign Gold, and #38bdf8 Baby Blue.
