# Website & Landing Page Builder Prompt Template

Paste this prompt into Antigravity whenever you want to create a new page or blog post:

```text
Using 01_Brain_Rules/MY_BRAND_RULES.md and 03_Website_Builder/gutenberg_starter_blocks.html, create a new [Landing Page / Blog Post] about "[TOPIC]".
Use Obsidian (#04070d) backgrounds, Sovereign Gold (#d4af37) headlines and 9999px pill buttons, and Luminous Baby Blue (#38bdf8) accents and comparison table borders.
```
