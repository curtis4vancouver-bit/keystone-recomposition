# My Brand & AI Brain Rules

- **Brand / Channel Name**: [Enter Your Brand or Channel Name]
- **Founder / Presenter Name**: [Enter Your Name]
- **Primary Website URL**: [https://yourwebsite.com]
- **Target Audience**: [Describe who your content and services help]
- **Core Product / Service Offer**: [Describe your main offer or service]

## Tone of Voice & Formatting Rules for Antigravity
1. Write with clear, practical, first-person builder authority — zero filler or generic buzzwords.
2. Keep every 10-second Google Flow video clip prompt strictly between **18 and 24 spoken words (~20 words)**.
3. Format all website and blog HTML blocks using our dark-luxury palette (`#04070d` Obsidian, `#d4af37` Sovereign Gold, `#38bdf8` Luminous Baby Blue).
