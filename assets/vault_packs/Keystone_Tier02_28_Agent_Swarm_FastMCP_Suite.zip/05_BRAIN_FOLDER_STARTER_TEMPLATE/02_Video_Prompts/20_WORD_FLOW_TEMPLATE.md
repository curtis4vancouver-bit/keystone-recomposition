# 10-Second Google Flow Scene Template (~20 Words)

Presenter says: "[18 to 24 spoken words]" Camera: With reference to me avatar, wearing cloth_1 with background background_1, [35mm cinema framing & natural gesture]
