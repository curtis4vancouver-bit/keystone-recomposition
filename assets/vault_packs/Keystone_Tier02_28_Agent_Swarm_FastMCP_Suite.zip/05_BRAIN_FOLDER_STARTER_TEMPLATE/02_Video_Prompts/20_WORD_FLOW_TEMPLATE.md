# Google Flow ~20-Word (18–24 Word) 10-Second Clip Template

Use this template for every 10-second clip in your video script:

## Clip [01] — [Scene Title]
- **Target Duration**: `10 seconds`
- **Spoken Word Count**: `[18 to 24 words]`
- **Spoken Line**:
  > "[Write your 18 to 24 word spoken sentence here so it delivers smoothly in 10 seconds without rushing.]"
- **Copy-Paste Google Flow Prompt**:
  ```text
  Cinematic 35mm medium shot of [Presenter & Wardrobe] in [Studio Setting & Lighting]. Natural two-handed speaking gesture with subtle camera push-in. The presenter speaks clearly: "[Paste 18-24 word spoken line here]"
  ```
- **Manual Export Checklist**:
  - [ ] Paste prompt into Google Flow and click Generate
  - [ ] Preview 10s audio and visual pacing
  - [ ] Click **Export / Download MP4 (1080p)** and save as `Clip_01.mp4`
