# My AI Brain — Starter Folder Template

Copy the folders in this directory (`01_Brain_Rules`, `02_Video_Prompts`, `03_Website_Builder`, `04_YouTube_Channel`) into your `My_AI_Brain/` workspace folder and open it inside **Google Antigravity**.

```text
My_AI_Brain/
├── 01_Brain_Rules/
│   └── MY_BRAND_RULES.md
├── 02_Video_Prompts/
│   └── 20_WORD_FLOW_TEMPLATE.md
├── 03_Website_Builder/
│   └── WEBSITE_PROMPT_TEMPLATE.md
└── 04_YouTube_Channel/
    └── CHANNEL_DEFAULTS_TEMPLATE.md
```
